let toggledCards = [];
let moves = 0;
let clockOff = true;
let time = 0;
let clockId;
let matched = 0; // Global Scope
const TOTAL_PAIRS = 8; // winning number of matches 16 cards / 2 = 8 pairs

// Modal tests
//time = 121;
//displayTime(); // 2:01
//moves = 16;
checkScore(); // 2 stars

writeModalStats(); // Write stats to modal
toggleModal(); // Open modal


/*
 * Creates a list that holds all the cards and displays them on the page
 */
const deck = document.querySelector('.deck');

function shuffleDeck() {
    const cardsToShuffle =  Array.from(document.querySelectorAll('.deck .card'));
    // const cardsToShuffle =  Array.from(document.querySelectorAll('.deck li'));
    // console.log('Cards to shuffle', cards);
    const shuffledCards = shuffle(cardsToShuffle);
    // console.log('Shuffled Cards:', shuffled);
    for(card of shuffledCards) {
        deck.appendChild(card);
    }
}

shuffleDeck();

/*
 * Display the cards on the page
 *   - shuffle the list of cards using the provided "shuffle" method below
 *   - loop through each card and create its HTML
 *   - add each card's HTML to the page
 */

// Shuffle function from http://stackoverflow.com/a/2450976
function shuffle(array) {
    var currentIndex = array.length, temporaryValue, randomIndex;

    while (currentIndex !== 0) {
        randomIndex = Math.floor(Math.random() * currentIndex);
        currentIndex -= 1;
        temporaryValue = array[currentIndex];
        array[currentIndex] = array[randomIndex];
        array[randomIndex] = temporaryValue;
    }

    return array;
}


/*
 * set up the event listener for a card. If a card is clicked:
 *  - display the card's symbol (put this functionality in another function that you call from this one)
 *  - add the card to a *list* of "open" cards (put this functionality in another function that you call from this one)
 *  - if the list already has another card, check to see if the two cards match
 *    + if the cards do match, lock the cards in the open position (put this functionality in another function that you call from this one)
 *    + if the cards do not match, remove the cards from the list and hide the card's symbol (put this functionality in another function that you call from this one)
 *    + increment the move counter and display it on the page (put this functionality in another function that you call from this one)
 *    + if all cards have matched, display a message with the final score (put this functionality in another function that you call from this one)
 */


// Set up the event listener for a card.
deck.addEventListener('click', event => {
    const clickTarget = event.target;
    if(isClickValid(clickTarget)) {
        if(clockOff) {
            startClock();
            clockOff = false;
        }
        // console.log("I'm a card!");
        // Call function that displays the card, in fact toggles the display state
        toggleCard(clickTarget);
        // Push toggled cards into the toggledCards array
        addToggledCard(clickTarget);
        if(toggledCards.length === 2) {
          // console.log('2 cards!');
          checkForMatch(clickTarget);
          addMove();
          checkScore();
        }

        // Compares matched counter aganist the TOTAL_PAIRS
        if(matched === TOTAL_PAIRS) {
            gameOver();
        }
    }
});

function isClickValid(clickTarget) {
    return (
        clickTarget.classList.contains('card') &&
        !clickTarget.classList.contains('match') &&
        toggledCards.length < 2 &&
        !toggledCards.includes(clickTarget)
    );
}

// If a card is clicked, display the card's symbol
function toggleCard(clickTarget) {
  clickTarget.classList.toggle('open');
  clickTarget.classList.toggle('show');
}


// Add the card to a *list* of "open" cards, by storing the
// cards in an array
function addToggledCard(clickTarget) {
  toggledCards.push(clickTarget);
  // console.log(toggledCards);
}


// If the list/array toggledCards already has another card, check to see if the two cards match
function checkForMatch(clickTarget) {
  if(toggledCards[0].firstElementChild.className ===
     toggledCards[1].firstElementChild.className) {

       cardsMatched();

  } else {
       cardsUnmatched();
  }
}

/*
 * If the cards do match, lock the cards in the open position
 */
function cardsMatched() {
  // console.log('First Card: ' + toggledCards[0].firstElementChild.className);
  // console.log('Second Card: ' + toggledCards[1].firstElementChild.className);
  // console.log('Match!');

  // if the cards do match, lock the cards in the open position by toggling the classList
  // and yell out Match to the console
  toggledCards[0].classList.toggle('match');
  toggledCards[1].classList.toggle('match');
  toggledCards = [];
  // console.log('Match! The list length: ' + toggledCards.length);
}


/*
 * If the cards do not match, remove the cards from the list and hide the card's symbol
 */
function cardsUnmatched() {
  // if the cards do not match, remove the cards from the list and hide the card's symbol
  // And yell out Not a Match to the console
      setTimeout(() => {
          toggleCard(toggledCards[0]);
          toggleCard(toggledCards[1]);
          toggledCards = [];
      }, 1000);
    // console.log('Not a match!');
    // toggleCard(toggledCards[0]);
    // toggleCard(toggledCards[1]);
    // toggledCards = [];
    // console.log('Not a match!');
    // console.log('Cards have been toggled off! The list length: ' + toggledCards.length);

}

/*
 * Increment the move counter and display it on the page
 */
function addMove() {
    moves++;
    const movesText = document.querySelector('.moves');
    movesText.innerHTML = moves;

}

/*
 * Update star functionality
 */
 function checkScore() {
   if(moves===16||moves===24) {
      hideStar();
   }
 }

 /*
  * Hides star
  */
  function hideStar() {
      const starList = document.querySelectorAll('.stars li');
      for(star of starList) {
          if(star.style.display !== 'none') {
              star.style.display = 'none';
              break;
          }
      }
  }

  /*
   * Set a timer
   */
   function startClock() {
     // let clockID = setTimeout(() => {
     //    console.log('1 second has passed');
     // }, 1000);
     clockId = setInterval(() => {
         time++;
         displayTime();
         // console.log(time);
     }, 1000);
   }

//startClock();

/*
 * Format the clock
 */
function displayTime() {
    const clock = document.querySelector('.clock');
    const minutes = Math.floor(time/60);
    const seconds = time%60;
    // console.log(clock);
    // clock.innerHTML = time;
    if(seconds<10) {
        clock.innerHTML = `${minutes}:0${seconds}`;
    } else {
        clock.innerHTML = `${minutes}:${seconds}`;
    }
}

/*
 * Stop the clock
 */
 function stopClock() {
    clearInterval(clockId);
 }

stopClock();

function toggleModal() {
    const modal = document.querySelector('.modal_background');
    modal.classList.toggle('hide');
}

toggleModal() // Open modal
toggleModal() // Close modal


/*
 * Function that writes to the Stats board
 */
 function writeModalStats() {
    const timeStat = document.querySelector('.modal_time');
    const clockTime = document.querySelector('.clock').innerHTML;
    const movesStat = document.querySelector('.modal_moves');
    const starsStat = document.querySelector('.modal_stars');
    const stars = getStars();

    timeStat.innerHTML = `Time = ${clockTime}`;
    movesStat.innerHTML = `Moves = ${moves}`;
    starsStat.innerHTML = `Stars = ${stars}`;

 }

 /*
  * Function that gets the list of stars already displayed on the deck
  * and returns the count
  */
function getStars() {
    const starList = document.querySelectorAll('.stars li');
    let starCount = 0;
    for(star of starList) {
        if(star.style.display !== 'none') {
            starCount++;
        }
    }
    console.log(starCount); //2
    return starCount;
}

/*
 * A click event listener for cancel button
 */
document.querySelector('.modal_cancel').addEventListener('click', () => {
    toggleModal();
});

// /*
//  * A click event listener for replay button
//  */
// document.querySelector('.modal_replay').addEventListener('click', () => {
//     console.log('replay');
//     // TODO: Call reset game HERE
// });

/*
 * Function that resets the game
 */
function resetGame() {
    resetClockAndTime();
    resetMoves();
    resetStars();
    shuffleDeck();
    resetCards();
}


/*
 * Function that resets clock and time
 */
function resetClockAndTime() {
    stopClock();
    clockOff = true;
    time = 0;
    displayTime();
}

function resetMoves() {
    moves = 0;
    document.querySelector('.moves').innerHTML = moves;
}

function resetStars() {
    stars = 0;
    const starList = document.querySelectorAll('.stars li');
    for(star of starList) {
        star.style.display = 'inline';
    }
}

/*
 * Attach click event handler to the reset button on the modal
 */
 function resetCards() {
     const cards = document.querySelectorAll('.deck li');
     for(let card of cards) {
         card.className = 'card';
     }
 }

/*
 * Resets the game and toggles the modal to exit the current game/restart a new game
 */
 function replayGame() {
     resetGame();
     toggleModal();
 }


/*
 * Attach click event handler to the reset button on the deck
 */
document.querySelector('.restart').addEventListener('click', resetGame);


/*
 * Attach click event handler to the reset button on the modal
 */
document.querySelector('.modal_replay').addEventListener('click', replayGame);

/*
 * Function that keeps track of matched pairs
 */
 function checkForMatch() {
    if(
       toggledCards[0].firstElementChild.className ===
       toggledCards[1].firstElementChild.className
    ) {
       toggledCards[0].classList.toggle('match');
       toggledCards[1].classList.toggle('match');
       toggledCards = [];
       matched++;
    }

 }


/*
 * Function gameOver stops the clock, write a game over message to modal
 * and toggle that modal
 */
 function gameOver() {
    stopClock();
    writeModalStats();
    toggleModal();
 }




